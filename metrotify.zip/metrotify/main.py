import json
import requests
from App import App

class App:
    def __init__(self):
        self.usuarios = []
        self.playlists = []
        self.canciones = []
        self.albumes = []


class MainMenu:
    def __init__(self, app):
        self.app = app
        self.options = {
            "1": self.ver_usuarios,
            "2": self.mostrar_musica,
            "3": self.crear_playlist,
            "4": self.crear_album,
            "5": self.crear_usuarios,
            "6": self.eliminar_playlist,
            "7": self.eliminar_album,
            "8": self.eliminar_usuario,
            "9": self.cambiar_datos_usuario,
            "10": self.dar_like,
            "11": self.exit
        }

    def run(self):
        while True:
            print("\n1. Ver usuarios")
            print("2. Mostrar musica")
            print("3. Crear playlist")
            print("4. Crear album")
            print("5. Crear usuarios")
            print("6. Eliminar playlist")
            print("7. Eliminar album")
            print("8. Eliminar usuario")
            print("9. Cambiar datos de usuario")
            print("10. Interaccion de likes")
            print("11. Salir del programa")
            opcion = input("Elige una opcion: ").lower()

            action = self.options.get(opcion)
            if action:
                action()
            else:
                print("Opcion no valida. Por favor, elige una opcion del 1 al 11.")

    def ver_usuarios(self):
        print("\nUsuarios:")
        for usuario in self.app.usuarios:
            print(json.dumps(usuario, indent=2))

    def mostrar_musica(self):
        print("\nMusica:")
        print("\nPlaylists:")
        for playlist in self.app.playlists:
            print(json.dumps(playlist, indent=2))
        print("\nCanciones:")
        for cancion in self.app.canciones:
            print(json.dumps(cancion, indent=2))
        print("\nAlbumes:")
        for album in self.app.albumes:
            print(json.dumps(album, indent=2))
    
    def crear_playlist(self):
        nombre = input("Nombre de la playlist: ")
        descripcion = input("¿Quieres agregar una descripción a la playlist? (s/n): ")
        emocion = input("¿Qué emoción te gustaría para esta playlist? ")

        if descripcion.lower() == "s":
            descripcion_playlist = input("Ingresa la descripción de la playlist: ")
            nueva_playlist = {"nombre": nombre, "descripcion": descripcion_playlist, "emocion": emocion}
        else:
            nueva_playlist = {"nombre": nombre, "emocion": emocion}

        self.app.playlists.append(nueva_playlist)
        print(f"Playlist '{nombre}' creada con la emoción '{emocion}'.")


    def crear_album(self):
        nombre = input("Nombre del album: ")
        artista = input("Nombre del artista: ")
        genero = input("Genero del album: ")
        duracion = input("Duracion del album: ")
        tracklist = input("Numero de canciones: ")
        album = {"nombre": nombre, "artista": artista, "genero": genero, "duracion": duracion, "tracklist": tracklist}
        self.app.albumes.append(album)
        print(f"Album '{nombre}' de '{artista}' creado.")

    def crear_usuarios(self):
        id = input("Coloca un id: ")
        nombre = input("Nombre del usuario: ")
        email = input("Email del usuario: ")
        tipo = input("Tipo de usuario (oyente/musico): ")
        usuario = {"username": nombre, "email": email, "type": tipo, "id": id}
        self.app.usuarios.append(usuario)
        print(f"Usuario '{nombre}' creado.")

    def eliminar_playlist(self):
        nombre = input("Nombre de la playlist a eliminar: ")
        playlist_a_eliminar = None

        for playlist in self.app.playlists:
            if "nombre" in playlist and playlist["nombre"] == nombre:
                playlist_a_eliminar = playlist
                break

        if playlist_a_eliminar:
            self.app.playlists.remove(playlist_a_eliminar)
            print(f"Playlist '{nombre}' eliminada.")
        else:
            print(f"No se encontró la playlist '{nombre}'. Por favor, verifica que el nombre esté escrito correctamente.")




    def eliminar_album(self):
        nombre = input("Nombre del album a eliminar: ")
        self.app.albumes = [album for album in self.app.albumes if album.get("nombre") != nombre]
        print(f"Album '{nombre}' eliminado.")


    def eliminar_usuario(self):
        nombre = input("Nombre del usuario a eliminar: ")
        tipo = input("Tipo del usuario a eliminar (oyente/musico): ")
        self.app.usuarios = [usuario for usuario in self.app.usuarios if usuario['username'] != nombre and usuario['type'] != tipo]
        print(f"Usuario '{nombre}' de tipo '{tipo}' eliminado.")

   
    def cambiar_datos_usuario(self):
        id = input("Ingresa el ID del usuario a modificar: ")
        usuario = next((usuario for usuario in self.app.usuarios if usuario['id'] == id), None)
        if usuario is not None:
            campos = ['id', 'username', 'email', 'type']
            descripciones = ['ID', 'nombre', 'email', 'type (musico/oyente)']
            for campo, descripcion in zip(campos, descripciones):
                print(f"{descripcion} actual: {usuario.get(campo, f'El usuario no tiene un {descripcion}.')}")
                nuevo_valor = input(f"Ingresa el nuevo {descripcion} del usuario o presiona enter para mantener el actual: ")
                usuario[campo] = nuevo_valor if nuevo_valor != '' else usuario[campo]
            print("\nLos datos del usuario han sido actualizados exitosamente.")
            for campo, descripcion in zip(campos, descripciones):
                print(f"{descripcion} modificado: {usuario.get(campo, f'El usuario no tiene un {descripcion}.')}")
        else:
            print(f"No se encontró un usuario con el ID '{id}'.")

    def dar_like(self):
        musico_id = input("Ingresa el ID del musico al que le quieres dar like: ")
        musico_encontrado = None
        for usuario in self.app.usuarios:
            if usuario["id"] == musico_id and usuario["type"] == "musico":
                musico_encontrado = usuario
                break

        if musico_encontrado:
            print(f"Has dado like al musico {musico_encontrado['username']}")
        else:
            print(f"El musico con ID '{musico_id}' no existe en nuestra base de datos.")

        
    def exit(self):
        continuar_interaccion = input("¿Desea continuar dando likes a músicos? (s/n): ")
        if continuar_interaccion.lower() == "s":
            self.dar_like()
        else:
            salir_programa = input("¿Desea salir del programa? (s/n): ")
            if salir_programa.lower() == "s":
                print("\nHasta luego! ¡Vuelva pronto!")
            else:
                print("\nVolviendo al menú principal...")


def load_json(url):
    response = requests.get(url)
    return response.json()

if __name__ == "__main__":
    app = App()

    json_urls = {
        "usuarios": "https://raw.githubusercontent.com/javiercillx/metrotify/main/usuarios.json",
        "playlists": "https://raw.githubusercontent.com/javiercillx/metrotify/main/playlists.json",
        "canciones": "https://raw.githubusercontent.com/javiercillx/metrotify/main/canciones.json",
        "albumes": "https://raw.githubusercontent.com/javiercillx/metrotify/main/albumes.json"
    }

    for key, url in json_urls.items():
        data = load_json(url)
        if hasattr(app, key):
            getattr(app, key).extend(data)
        else:
            setattr(app, key, data)

    menu = MainMenu(app)
    menu.run()
    print("\nJSONs:")
    print("Usuarios:")
    print(json.dumps(app.usuarios, indent=2))
    print("Playlists:")
    print(json.dumps(app.playlists, indent=2))
    print("Canciones:")
    print(json.dumps(app.canciones, indent=2))
    print("Albumes:")
    print(json.dumps(app.albumes, indent=2))