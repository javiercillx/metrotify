class Usuario:
    tipo=None
    def __init__(self,id,name,email,user_name) -> None:
        self.id=id
        self.name=name
        self.email=email
        self.userName=user_name

class Escucha(Usuario):
    tipo="Escucha"
    def __init__(self, id, name, email, user_name) -> None:
        super().__init__(id, name, email, user_name)

class Musico(Usuario):
    tipo="Musico"
    def __init__(self, id, name, email, user_name) -> None:
        super().__init__(id, name, email, user_name)