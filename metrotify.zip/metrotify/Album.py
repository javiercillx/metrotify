class Album:
    def __init__(self, id,nombre,descripcion,portada,publicacion,genero,artista,canciones) -> None:
        self.id=id
        self.nombre=nombre
        self.descipcion=descripcion
        self.portada=portada
        self.publicacion=publicacion
        self.genero=genero
        self.artista=artista
        self.canciones=canciones