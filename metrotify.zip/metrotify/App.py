from iniciadores import cargar_api, iniciar_canciones
from GestionPerfil import GestionPerfil
import json
import requests
import os


class App:
    canciones=[]
    usuarios=[]
    albumes=[]
    playlists=[]
    escuchas=[]
    musicos=[]

    def __init__(self) -> None:
        self.gestionPerfil=GestionPerfil(self)

    def iniciar_Apis(self):
        self.usuarios=requests.get("https://raw.githubusercontent.com/javiercillx/metrotify/main/usuarios.json").json()
        print(self.usuarios)  
        self.albumes=requests.get("https://raw.githubusercontent.com/javiercillx/metrotify/main/albumes.json").json()
        print(self.albumes)  
        self.playlists=requests.get("https://raw.githubusercontent.com/javiercillx/metrotify/main/playlists.json").json()
        print(self.playlists)  

    def start(self):
        self.iniciar_Apis()
        usuarios_convertidos=self.gestionPerfil.crear_usuarios(self.usuarios)
        self.musicos=usuarios_convertidos[1]
        self.escuchas=usuarios_convertidos[0]
        albumes_convertidos=self.gestionPerfil.crear_albumes(self.albumes)
        self.canciones=albumes_convertidos[0]
        self.albumes=albumes_convertidos[1]

        with open("usuarios.txt", "w") as f:
            f.write(json.dumps(self.usuarios, default=lambda x: x.__dict__))
        with open("albumes.txt", "w") as f:
            f.write(json.dumps(self.albumes, default=lambda x: x.__dict__))
        with open("canciones.txt", "w") as f:
            f.write(json.dumps(self.canciones, default=lambda x: x.__dict__))


    def iniciar_canciones():
        if os.path.getsize("canciones.txt") > 0:  
            with open("canciones.txt", "r") as f:
                canciones = json.loads(f.read())
        else:
            canciones = [] 
            
    @staticmethod
    def quick_sort(lista):
        if len(lista) <= 1:
            return lista
        else:
            pivote = lista[0]
            menores = [i for i in lista[1:] if i < pivote]
            iguales = [i for i in lista if i == pivote]
            mayores = [i for i in lista[1:] if i > pivote]
            return App.quick_sort(menores) + iguales + App.quick_sort(mayores)


