import json
import requests
from App import App

class App:
    def __init__(self):
        self.usuarios = []
        self.playlists = []
        self.canciones = []
        self.albumes = []


class MainMenu:
    def __init__(self, app):
        self.app = app
        self.options = {
            "1": self.ver_usuarios,
            "2": self.mostrar_musica,
            "3": self.crear_playlist,
            "4": self.crear_album,
            "5": self.crear_usuarios,
            "6": self.eliminar_playlist,
            "7": self.eliminar_album,
            "8": self.eliminar_usuario,
            "9": self.cambiar_datos_usuario,
            "10": exit
        }

    def run(self):
        while True:
            print("\n1. Ver usuarios")
            print("2. Mostrar musica")
            print("3. Crear playlist")
            print("4. Crear album")
            print("5. Crear usuarios")
            print("6. Eliminar playlist")
            print("7. Eliminar album")
            print("8. Eliminar usuario")
            print("9. Cambiar datos de usuario")
            print("10. Salir del programa")
            opcion = input("Elige una opcion: ").lower()

            action = self.options.get(opcion)
            if action:
                action()
            else:
                print("Opcion no valida. Por favor, elige una opcion del 1 al 10.")

    def ver_usuarios(self):
        print("\nUsuarios:")
        for usuario in self.app.usuarios:
            print(json.dumps(usuario, indent=2))

    def mostrar_musica(self):
        print("\nMusica:")
        print("\nPlaylists:")
        for playlist in self.app.playlists:
            print(json.dumps(playlist, indent=2))
        print("\nCanciones:")
        for cancion in self.app.canciones:
            print(json.dumps(cancion, indent=2))
        print("\nAlbumes:")
        for album in self.app.albumes:
            print(json.dumps(album, indent=2))
    
    def crear_playlist(self):
        nombre = input("Nombre de la playlist: ")
        descripcion = input("¿Quieres agregar una descripción a la playlist? (s/n): ")
        emocion = input("¿Qué emoción te gustaría para esta playlist? ")

        if descripcion.lower() == "s":
            descripcion_playlist = input("Ingresa la descripción de la playlist: ")
            nueva_playlist = {"nombre": nombre, "descripcion": descripcion_playlist, "emocion": emocion}
        else:
            nueva_playlist = {"nombre": nombre, "emocion": emocion}

        self.app.playlists.append(nueva_playlist)
        print(f"Playlist '{nombre}' creada con la emoción '{emocion}'.")


    def crear_album(self):
        nombre = input("Nombre del album: ")
        artista = input("Nombre del artista: ")
        genero = input("Genero del album: ")
        duracion = input("Duracion del album: ")
        tracklist = input("Numero de canciones: ")
        album = {"nombre": nombre, "artista": artista, "genero": genero, "duracion": duracion, "tracklist": tracklist}
        self.app.albumes.append(album)
        print(f"Album '{nombre}' de '{artista}' creado.")

    def crear_usuarios(self):
        id = input("Coloca un id: ")
        nombre = input("Nombre del usuario: ")
        email = input("Email del usuario: ")
        tipo = input("Tipo de usuario (oyente/musico): ")
        usuario = {"username": nombre, "email": email, "type": tipo, "id": id}
        self.app.usuarios.append(usuario)
        print(f"Usuario '{nombre}' creado.")

    def eliminar_playlist(self):
        nombre = input("Nombre de la playlist a eliminar: ")
        playlist_a_eliminar = None

        for playlist in self.app.playlists:
            if "nombre" in playlist and playlist["nombre"] == nombre:
                playlist_a_eliminar = playlist
                break

        if playlist_a_eliminar:
            self.app.playlists.remove(playlist_a_eliminar)
            print(f"Playlist '{nombre}' eliminada.")
        else:
            print(f"No se encontró la playlist '{nombre}'. Por favor, verifica que el nombre esté escrito correctamente.")




    def eliminar_album(self):
        nombre = input("Nombre del album a eliminar: ")
        self.app.albumes = [album for album in self.app.albumes if album.get("nombre") != nombre]
        print(f"Album '{nombre}' eliminado.")


    def eliminar_usuario(self):
        nombre = input("Nombre del usuario a eliminar: ")
        tipo = input("Tipo del usuario a eliminar (oyente/musico): ")
        self.app.usuarios = [usuario for usuario in self.app.usuarios if usuario['username'] != nombre and usuario['type'] != tipo]
        print(f"Usuario '{nombre}' de tipo '{tipo}' eliminado.")

   
    def cambiar_datos_usuario(self):
        id_usuario = input("Ingresa el ID del usuario a modificar: ")
        
        for usuario in self.app.usuarios:
            if usuario["id"] == id_usuario:
                print("Datos actuales del usuario:")
                print(f"ID: {usuario['id']}")
                print(f"Nombre: {usuario['nombre']}")
                print(f"Email: {usuario['email']}")
                print(f"Tipo: {usuario['tipo']}")

                opcion_id = input("¿Quieres cambiar el ID? (s/n): ")
                if opcion_id.lower() == "s":
                    nuevo_id = input("Ingresa el nuevo ID del usuario: ")
                    usuario["id"] = nuevo_id

                opcion_nombre = input("¿Quieres cambiar el nombre de usuario? (s/n): ")
                if opcion_nombre.lower() == "s":
                    nuevo_nombre = input("Ingresa el nuevo nombre de usuario: ")
                    usuario["nombre"] = nuevo_nombre

                opcion_email = input("¿Quieres cambiar el email del usuario? (s/n): ")
                if opcion_email.lower() == "s":
                    nuevo_email = input("Ingresa el nuevo email del usuario: ")
                    usuario["email"] = nuevo_email

                opcion_tipo = input("¿Quieres ser músico o oyente? (musico/oyente): ")
                if opcion_tipo.lower() == "musico":
                    usuario["tipo"] = "musico"
                else:
                    usuario["tipo"] = "oyente"

                print(f"Datos del usuario con ID {id_usuario} actualizados correctamente.")
                break
        else:
            print(f"No se encontró el usuario con ID {id_usuario}.")

def load_json(url):
    response = requests.get(url)
    return response.json()

if __name__ == "__main__":
    app = App()

    json_urls = {
        "usuarios": "https://raw.githubusercontent.com/javiercillx/metrotify/main/usuarios.json",
        "playlists": "https://raw.githubusercontent.com/javiercillx/metrotify/main/playlists.json",
        "canciones": "https://raw.githubusercontent.com/javiercillx/metrotify/main/canciones.json",
        "albumes": "https://raw.githubusercontent.com/javiercillx/metrotify/main/albumes.json"
    }

    for key, url in json_urls.items():
        data = load_json(url)
        if hasattr(app, key):
            getattr(app, key).extend(data)
        else:
            setattr(app, key, data)

    menu = MainMenu(app)
    menu.run()
    print("\nJSONs:")
    print("Usuarios:")
    print(json.dumps(app.usuarios, indent=2))
    print("Playlists:")
    print(json.dumps(app.playlists, indent=2))
    print("Canciones:")
    print(json.dumps(app.canciones, indent=2))
    print("Albumes:")
    print(json.dumps(app.albumes, indent=2))