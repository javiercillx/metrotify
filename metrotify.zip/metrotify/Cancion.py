import random
class Cancion:
    def __init__(self, id,name,duracion,link,escuchada=int(random.random()*10000)) -> None:
        self.id=id
        self.name=name
        self.duracion=duracion
        self.link=link
        self.escuchada=int(random.random()*10000)

    
    def show(self):
        print(f"{self.name} ({self.escuchada})")
