import json
from urllib.request import urlopen
from Album import Album
from Cancion import Cancion
def cargar_api(url):
    response = urlopen(url)
    data_json = json.loads(response.read())
    return data_json

def iniciar_canciones():
    canciones=None
    with open("guardado.txt","r") as f:
        canciones=json.loads(f.read())

    canciones_objetos=[]
      
    for cancion in canciones:
        cancion=Cancion(cancion["id"],cancion["name"],cancion["duracion"],cancion["link"], escuchada=cancion["escuchada"])
        canciones_objetos.append(cancion)

    print(canciones_objetos)