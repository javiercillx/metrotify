from Usuario import Usuario, Escucha, Musico
from Cancion import Cancion
from Album import Album
class GestionPerfil:
    def __init__(self,app) -> None:
        self.app=app
    def crear_usuarios(self,usuarios):
        escuchas=[]
        musicos=[]
        for usuario in usuarios:
            if usuario["type"]=="listener":
                escuchas.append(Escucha(usuario["id"],usuario["name"],usuario["email"],usuario["username"]))
            else:
                musicos.append(Musico(usuario["id"],usuario["name"],usuario["email"],usuario["username"]))

        return (escuchas,musicos)
        
    def crear_albumes(self, albumes):
        albumes_objeto = []
        canciones = []
        for album in albumes:
            canciones_album = []
            if "tracklist" in album:
                for cancion in album["tracklist"]:
                    cancion = Cancion(cancion["id"], cancion["name"], cancion["duration"], cancion["link"])
                    canciones.append(cancion)
                    canciones_album.append(cancion)
                albumes_objeto.append(Album(album["id"], album["name"], album["description"], album["cover"], album["published"], album["genre"], album["artist"], canciones_album))
        return (canciones, albumes_objeto)
